HIKE SMP RANK BADGES RESOURCE PACK
==================================

This optional pack contains the supplied Hike SMP logo as pack.png and badge glyphs
based on the supplied rank artwork:

  Owner, Dev, Admin, Mod, Trial Staff, Member, and Muted.

Helper is deliberately NOT included.

HOW TO HOST IT
==============

1. Zip the CONTENTS of this folder, not the outer folder itself.
2. Upload that ZIP to a direct HTTPS download URL. The URL must download the ZIP directly.
3. Put the URL and the SHA-1 value in server.properties:

   resource-pack=<your direct HTTPS ZIP URL>
   resource-pack-sha1=<the ZIP SHA-1>
   resource-pack-prompt={"text":"Hike SMP ranks and visuals"}
   require-resource-pack=false

Players may decline the pack. The server must preserve the normal colored rank prefix
as the fallback for clients that do not use the custom badge font.

CUSTOM FONT IDENTIFIERS
=======================

Font key: isakranks:badges
Glyphs:
  U+E001 owner
  U+E002 dev
  U+E003 admin
  U+E004 mod
  U+E005 trial staff
  U+E006 member
  U+E007 muted

