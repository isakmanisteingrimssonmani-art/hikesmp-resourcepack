HIKE SMP RANK BADGES + LIVE EVENT AUDIO V9
========================

Every badge bitmap is exactly 51 pixels wide and 9 pixels tall. The pack adds
the glyphs to both isakranks:badges and minecraft:default so they can render in
TAB, overhead nametags, chat/display names, and ordinary scoreboard player rows.

Included mappings:

  U+E001 owner / founder
  U+E002 dev / developer
  U+E003 admin / administrator
  U+E004 mod / moderator
  U+E005 trial_staff / trialstaff
  U+E006 member
  U+E007 muted
  U+E008 debug
  U+E009 helper
  U+E00A media / youtuber

IsakRanks sends the hosted pack on join. Do not put this ZIP in the plugins
folder. Host the ZIP at the direct URL configured by IsakRanks instead.

V9 keeps all V8 rank assets and the 7 dB music boost, and time-fits the Earth
25236 soundtrack to exactly 351.000 seconds so it starts at event second 0 and
ends on the full-light timestamp. Its measured peak remains approximately
-1.5 dB, below clipping.
