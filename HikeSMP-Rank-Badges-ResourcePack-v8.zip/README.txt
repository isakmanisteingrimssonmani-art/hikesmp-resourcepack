HIKE SMP RANK BADGES + LIVE EVENT AUDIO V8
========================

Every badge bitmap is exactly 51 pixels wide and 9 pixels tall. The pack adds
the glyphs to both isakranks:badges and minecraft:default so they can render in
TAB, overhead nametags, chat/display names, and ordinary scoreboard player rows.

Included mappings:

  U+E001 owner / founder
  U+E002 dev / developer
  U+E003 admin / administrator
  U+E004 mod / moderator
  U+E005 trial_staff / trialstaff
  U+E006 member
  U+E007 muted
  U+E008 debug
  U+E009 helper
  U+E00A media / youtuber

IsakRanks sends the hosted pack on join. Do not put this ZIP in the plugins
folder. Host the ZIP at the direct URL configured by IsakRanks instead.

V8 keeps all V7 rank assets and raises the Earth 25236 live-event soundtrack
by 7 dB. Its measured peak remains below clipping at approximately -1.5 dB.
