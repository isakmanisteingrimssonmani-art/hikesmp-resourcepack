HIKE SMP RANK BADGES + EVENTS + HELICOPTERS V15
========================

Rank badge bitmaps are 9 pixels tall. The moderator badge now uses the new
40-pixel-wide cyan MOD artwork; the remaining existing badges retain their
51-pixel width. The pack adds the glyphs to both isakranks:badges and minecraft:default so they can render in
TAB, overhead nametags, chat/display names, and ordinary scoreboard player rows.

Included mappings:

  U+E001 owner / founder
  U+E002 dev / developer
  U+E003 admin / administrator
  U+E004 mod / moderator
  U+E005 trial_staff / trialstaff
  U+E006 member
  U+E007 muted
  U+E008 debug
  U+E009 helper
  U+E00A media / youtuber

IsakRanks sends the hosted pack on join. Do not put this ZIP in the plugins
folder. Host the ZIP at the direct URL configured by IsakRanks instead.

V11 replaces the moderator rank artwork and keeps all other rank assets plus
the 7 dB music boost without time-stretching
either song. The 239.351-second main track drives a faster cinematic clock.
The supplied 62.717-second second song is available as hikesmp:last_stand and
starts when the final preset fight begins. Both files retain their natural
tempo and remain below clipping.

V15 adds hikesmp:helicopter.rotor for HikeHelicopters. The 1.673-second rotor
loop is "Propeller (Cartoon) Loop" by Mish7913, released under CC0:
https://opengameart.org/content/propeller-cartoon-loop

V15 also carries Minecraft's vanilla farmer profession texture at:
assets/minecraft/textures/entity/villager/profession/farmer.png
The server converts this source artwork into the sell-top player cosmetic;
the raw villager UV is not incorrectly applied directly to a player model.
