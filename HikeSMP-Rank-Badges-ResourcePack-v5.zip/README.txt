HIKE SMP RANK BADGES RESOURCE PACK
==================================

This optional pack contains the supplied Hike SMP logo as pack.png and compact,
readable pixel-art rank-name badges:

  Owner, Dev, Admin, Mod, Trial Staff, Member, and Muted.

Helper is deliberately NOT included.

HOW TO HOST IT
==============

1. Zip the CONTENTS of this folder, not the outer folder itself.
2. Upload that ZIP to a direct HTTPS download URL. The URL must download the ZIP directly.
3. Put the URL and the SHA-1 value in server.properties:

   resource-pack=<your direct HTTPS ZIP URL>
   resource-pack-sha1=<the ZIP SHA-1>
   resource-pack-prompt={"text":"Hike SMP ranks and visuals"}
   require-resource-pack=false

Players may decline the pack. IsakRanks keeps the normal colored rank prefix as the
fallback for clients that do not use the custom badge font. After Minecraft confirms
that this pack loaded, the emblem intentionally replaces the rank word for every
supported rank, so the nametag is shown as: [emblem] | username.

CUSTOM FONT IDENTIFIERS
=======================

Font key: isakranks:badges
Glyphs:
  U+E001 owner / founder: gold OWNER badge
  U+E002 dev / developer: purple DEV badge
  U+E003 admin: red ADMIN badge
  U+E004 mod / moderator: cyan MOD badge
  U+E005 trial staff: blue TRIAL badge
  U+E006 member: green MEMBER badge
  U+E007 muted: gray MUTED badge

